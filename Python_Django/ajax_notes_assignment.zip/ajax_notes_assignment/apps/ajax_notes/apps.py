from __future__ import unicode_literals

from django.apps import AppConfig


class AjaxNotesConfig(AppConfig):
    name = 'ajax_notes'
