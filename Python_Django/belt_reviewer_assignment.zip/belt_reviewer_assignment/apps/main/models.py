from __future__ import unicode_literals
from django.db import models
from ..login_register.models import Users, UsersManager
from ..library.models import Books, Authors, Reviews
